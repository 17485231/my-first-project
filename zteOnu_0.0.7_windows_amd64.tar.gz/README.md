# zteOnu
Type `./zteonu -h` for help
